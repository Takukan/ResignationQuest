// Data created with Img2CPC - (c) Retroworks - 2007-2017
#ifndef _IMG_RIGHTBOUND_H_
#define _IMG_RIGHTBOUND_H_

#include <types.h>
#define SPRIGHTBOUND_W 8
#define SPRIGHTBOUND_H 16
extern const u8 spRightBound[8 * 16];

#endif
