// Data created with Img2CPC - (c) Retroworks - 2007-2017
#ifndef _IMG_DEFMASKED_H_
#define _IMG_DEFMASKED_H_

#include <types.h>
#define SPDEFMASKED_W 8
#define SPDEFMASKED_H 16
extern const u8 spDefMasked[8 * 16];

#endif
