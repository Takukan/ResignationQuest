// Data created with Img2CPC - (c) Retroworks - 2007-2017
#ifndef _IMG_LOWERRIGHTCORNER_H_
#define _IMG_LOWERRIGHTCORNER_H_

#include <types.h>
#define SPLOWERRIGHTCORNER_W 8
#define SPLOWERRIGHTCORNER_H 16
extern const u8 spLowerRightCorner[8 * 16];

#endif
