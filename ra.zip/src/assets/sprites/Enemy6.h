// Data created with Img2CPC - (c) Retroworks - 2007-2017
#ifndef _IMG_ENEMY6_H_
#define _IMG_ENEMY6_H_

#include <types.h>
#define SPENEMY6_W 8
#define SPENEMY6_H 16
extern const u8 spEnemy6[8 * 16];

#endif
