// Data created with Img2CPC - (c) Retroworks - 2007-2017
#ifndef _IMG_ENEMY2_H_
#define _IMG_ENEMY2_H_

#include <types.h>
#define SPENEMY2_W 8
#define SPENEMY2_H 16
extern const u8 spEnemy2[8 * 16];

#endif
