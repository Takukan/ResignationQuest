// Data created with Img2CPC - (c) Retroworks - 2007-2017
#ifndef _IMG_HEALTHMASKED_H_
#define _IMG_HEALTHMASKED_H_

#include <types.h>
#define SPHEALTHMASKED_W 8
#define SPHEALTHMASKED_H 16
extern const u8 spHealthMasked[8 * 16];

#endif
