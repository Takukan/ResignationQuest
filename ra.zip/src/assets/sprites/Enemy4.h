// Data created with Img2CPC - (c) Retroworks - 2007-2017
#ifndef _IMG_ENEMY4_H_
#define _IMG_ENEMY4_H_

#include <types.h>
#define SPENEMY4_W 8
#define SPENEMY4_H 16
extern const u8 spEnemy4[8 * 16];

#endif
