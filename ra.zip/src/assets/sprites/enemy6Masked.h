// Data created with Img2CPC - (c) Retroworks - 2007-2017
#ifndef _IMG_ENEMY6MASKED_H_
#define _IMG_ENEMY6MASKED_H_

#include <types.h>
#define M_ENEMY6MASKED_W 8
#define M_ENEMY6MASKED_H 16
extern const u8 m_enemy6Masked[2 * 8 * 16];

#endif
