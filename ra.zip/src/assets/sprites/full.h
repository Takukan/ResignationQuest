// Data created with Img2CPC - (c) Retroworks - 2007-2017
#ifndef _IMG_FULL_H_
#define _IMG_FULL_H_

#include <types.h>
#define SPFULL_W 8
#define SPFULL_H 16
extern const u8 spFull[8 * 16];

#endif
