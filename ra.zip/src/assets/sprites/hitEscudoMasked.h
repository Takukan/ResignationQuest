// Data created with Img2CPC - (c) Retroworks - 2007-2017
#ifndef _IMG_HITESCUDOMASKED_H_
#define _IMG_HITESCUDOMASKED_H_

#include <types.h>
#define M_HITESCUDOMASKED_W 8
#define M_HITESCUDOMASKED_H 16
extern const u8 m_hitEscudoMasked[2 * 8 * 16];

#endif
