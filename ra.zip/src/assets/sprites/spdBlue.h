// Data created with Img2CPC - (c) Retroworks - 2007-2017
#ifndef _IMG_SPDBLUE_H_
#define _IMG_SPDBLUE_H_

#include <types.h>
#define SPSPDBLUE_W 8
#define SPSPDBLUE_H 16
extern const u8 spSpdBlue[8 * 16];

#endif
