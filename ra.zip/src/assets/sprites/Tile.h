// Data created with Img2CPC - (c) Retroworks - 2007-2017
#ifndef _IMG_TILE_H_
#define _IMG_TILE_H_

#include <types.h>
#define SPTILE_W 8
#define SPTILE_H 16
extern const u8 spTile[8 * 16];

#endif
