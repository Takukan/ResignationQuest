// Data created with Img2CPC - (c) Retroworks - 2007-2017
#ifndef _IMG_UPPERLEFTCORNER_H_
#define _IMG_UPPERLEFTCORNER_H_

#include <types.h>
#define SPUPPERLEFTCORNER_W 8
#define SPUPPERLEFTCORNER_H 16
extern const u8 spUpperLeftCorner[8 * 16];

#endif
