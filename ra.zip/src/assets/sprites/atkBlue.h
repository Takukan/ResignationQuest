// Data created with Img2CPC - (c) Retroworks - 2007-2017
#ifndef _IMG_ATKBLUE_H_
#define _IMG_ATKBLUE_H_

#include <types.h>
#define SPATKBLUE_W 8
#define SPATKBLUE_H 16
extern const u8 spAtkBlue[8 * 16];

#endif
