// Data created with Img2CPC - (c) Retroworks - 2007-2017
#ifndef _IMG_UPPERBOUND_H_
#define _IMG_UPPERBOUND_H_

#include <types.h>
#define SPUPPERBOUND_W 8
#define SPUPPERBOUND_H 16
extern const u8 spUpperBound[8 * 16];

#endif
