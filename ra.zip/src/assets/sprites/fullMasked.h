// Data created with Img2CPC - (c) Retroworks - 2007-2017
#ifndef _IMG_FULLMASKED_H_
#define _IMG_FULLMASKED_H_

#include <types.h>
#define SPFULLMASKED_W 8
#define SPFULLMASKED_H 16
extern const u8 spFullMasked[8 * 16];

#endif
