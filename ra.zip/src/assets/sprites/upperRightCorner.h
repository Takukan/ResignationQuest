// Data created with Img2CPC - (c) Retroworks - 2007-2017
#ifndef _IMG_UPPERRIGHTCORNER_H_
#define _IMG_UPPERRIGHTCORNER_H_

#include <types.h>
#define SPUPPERRIGHTCORNER_W 8
#define SPUPPERRIGHTCORNER_H 16
extern const u8 spUpperRightCorner[8 * 16];

#endif
